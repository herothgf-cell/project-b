import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp, mkdir, writeFile, rm} from 'node:fs/promises';
import {tmpdir} from 'node:os'; import path from 'node:path';
import {startServer} from '../../tools/content-editor/server.mjs';
import {hashProfile} from '../../tools/content-editor/profile.mjs';
test('loopback API enforces token and origin and saves with conflict detection',async t=>{
 const root=await mkdtemp(path.join(tmpdir(),'editor-'));t.after(()=>rm(root,{recursive:true,force:true}));
 await mkdir(path.join(root,'config/content'),{recursive:true}); const catalog={schemaVersion:1,entries:[{id:'n',group:'effects',type:'number',min:0,max:10,editable:true}]};
 const profile={schemaVersion:1,id:'default',revision:1,contentHash:'',values:[{id:'n',value:'1'}]};profile.contentHash=hashProfile(profile);
 await writeFile(path.join(root,'config/content/catalog.json'),JSON.stringify(catalog));await writeFile(path.join(root,'config/content/default-profile.json'),JSON.stringify(profile));
 const app=await startServer({root,port:0});t.after(()=>app.close()); const base=app.url.split('#')[0].replace(/\/$/,'');
 assert.equal((await fetch(base+'/api/bootstrap')).status,403);
 const headers={'X-Content-Token':app.token,Origin:base,'Content-Type':'application/json'};
 assert.equal((await fetch(base+'/api/bootstrap',{headers})).status,200);
 assert.equal((await fetch(base+'/api/bootstrap',{headers:{...headers,Origin:'http://evil.test'}})).status,403);
 let r=await fetch(base+'/api/save',{method:'POST',headers,body:JSON.stringify({profile,expectedRevision:0})}); assert.equal(r.status,200);
 r=await fetch(base+'/api/save',{method:'POST',headers,body:JSON.stringify({profile,expectedRevision:0})}); assert.equal(r.status,409);
});

test('apply writes pending profile and rejects path, malformed import, and missing game',async t=>{
 const root=await mkdtemp(path.join(tmpdir(),'editor-'));t.after(()=>rm(root,{recursive:true,force:true}));await mkdir(path.join(root,'config/content'),{recursive:true});
 const catalog={schemaVersion:1,entries:[{id:'n',type:'number',min:0,max:10,editable:true}]};const profile={schemaVersion:1,id:'default',revision:1,contentHash:'',values:[{id:'n',value:'1'}]};profile.contentHash=hashProfile(profile);
 await writeFile(path.join(root,'config/content/catalog.json'),JSON.stringify(catalog));await writeFile(path.join(root,'config/content/default-profile.json'),JSON.stringify(profile));const app=await startServer({root,port:0});t.after(()=>app.close());const base=app.url.split('#')[0].replace(/\/$/,'');const headers={'X-Content-Token':app.token,Origin:base,'Content-Type':'application/json'};
 const post=(name,body)=>fetch(base+'/api/'+name,{method:'POST',headers,body:JSON.stringify(body)});
 let r=await post('apply',{profile});assert.equal(r.status,200);assert.match((await r.json()).status,/다음 새/);
 r=await post('import',{raw:'{"schemaVersion":1,"schemaVersion":1}'});assert.equal(r.status,400);
 r=await post('test',{profile});assert.equal(r.status,404);
 r=await fetch(base+'/api/profiles/%2e%2e%2fsecret',{headers});assert.equal(r.status,400);
 r=await post('validate',{profile,huge:'x'.repeat(2*1024*1024)});assert.equal(r.status,413);
});
